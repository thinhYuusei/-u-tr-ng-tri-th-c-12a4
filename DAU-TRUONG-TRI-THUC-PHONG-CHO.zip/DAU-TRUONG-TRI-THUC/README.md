# ĐẤU TRƯỜNG TRI THỨC – LỊCH SỬ TÂY NINH

Website Game Show trắc nghiệm gồm 4 vòng, 10 câu/vòng, 40 câu hỏi mẫu. Giao diện có trang chủ, thí sinh, MC và Admin.

## Phòng chờ thí sinh\nThí sinh đăng nhập sẽ được đưa vào phòng chờ riêng. Tại đây, hệ thống hiển thị tên và mã thí sinh cùng trạng thái đang chờ. Khi MC nhấn **Bắt đầu / Mở câu**, phòng chờ tự chuyển sang giao diện câu hỏi.\n\n## Chạy thử trên máy tính
1. Giải nén ZIP.
2. Mở thư mục bằng VS Code.
3. Cài tiện ích **Live Server**.
4. Nhấn chuột phải `index.html` → **Open with Live Server**.
5. Mở thêm `mc.html` trong cùng trình duyệt để điều khiển. Thí sinh đăng nhập ở trang chủ và vào contestant.html.

> Không nên mở trực tiếp bằng `file://` vì trình duyệt có thể chặn tải file JSON. Dùng Live Server hoặc hosting.

## Tài khoản / đăng nhập
- Thí sinh: tự nhập họ tên và mã thí sinh ở trang chủ.
- MC: vào `mc.html`.
- Admin: vào `admin.html`.
Bản hiện tại là bản mẫu chạy thử, chưa có xác thực bảo mật cho MC/Admin.

## Đưa lên GitHub Pages
1. Tạo repository mới trên GitHub.
2. Upload toàn bộ file và thư mục trong dự án.
3. Vào Settings → Pages.
4. Chọn Deploy from a branch → `main` → `/ (root)` → Save.
5. Mở URL GitHub Pages được cung cấp.

## Lưu ý quan trọng về dữ liệu
Bản ZIP hiện tại dùng `localStorage` để chạy thử trên cùng trình duyệt. Dữ liệu không tự đồng bộ giữa nhiều máy hoặc điện thoại. Để tổ chức cuộc thi thật, cần cấu hình Firebase Firestore và bổ sung xác thực, phân quyền bảo mật, luật khóa đáp án và đồng bộ thời gian thực. Không đưa API key bí mật hoặc mật khẩu quản trị vào mã nguồn công khai.

## Chỉnh sửa câu hỏi
Mở `data/questions.json`. Mỗi câu có:
- `round`: số vòng từ 1 đến 4
- `number`: thứ tự câu từ 1 đến 10
- `question`: nội dung
- `options`: đáp án A/B/C/D
- `correct`: đáp án đúng
- `points`: điểm câu hỏi
- `seconds`: thời gian gợi ý (giây)
- `topic`: chủ đề

**Khuyến nghị:** Rà soát lại đáp án và tư liệu lịch sử theo tài liệu chính thức của địa phương trước khi dùng trong hội thi chính thức. Bộ câu hỏi hiện là nội dung mẫu khởi đầu, không thay thế thẩm định chuyên môn.

## Cấu trúc
- `index.html`: Trang chủ / đăng nhập thí sinh
- `contestant.html`: Giao diện thí sinh
- `mc.html`: Bàn điều khiển MC
- `admin.html`: Trang quản trị
- `css/style.css`: Giao diện
- `js/app.js`: Xử lý tương tác và tính điểm
- `data/questions.json`: 40 câu hỏi mẫu
