const STORE='dtt_tayninh_v1';
let questions=[];
let state={players:[],round:1,index:0,status:'waiting',revealed:false,answers:{}};
const $=id=>document.getElementById(id);
const read=()=>{try{return JSON.parse(localStorage.getItem(STORE))||null}catch(e){return null}};
const save=()=>localStorage.setItem(STORE,JSON.stringify(state));
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function init(){try{questions=await fetch('data/questions.json').then(r=>r.json())}catch(e){questions=[]}
const old=read();if(old)state={...state,...old};const page=location.pathname.split('/').pop();
if(page==='contestant.html')renderContestant();if(page==='mc.html')renderMC();if(page==='admin.html')renderAdmin();
window.addEventListener('storage',e=>{if(e.key===STORE){const v=read();if(v){state=v;renderContestant();renderMC();renderAdmin()}}});
}
function current(){return questions.find(q=>q.round===state.round&&q.number===state.index+1)}
function me(){return sessionStorage.getItem('dtt_player')||''}
function score(p){return p.score||0}
function sorted(){return [...state.players].sort((a,b)=>score(b)-score(a))}
function board(target){if(!$(target))return;const list=sorted();$(target).innerHTML=list.length?`<table class="table"><thead><tr><th>HẠNG</th><th>THÍ SINH</th><th>MÃ</th><th>ĐIỂM</th></tr></thead><tbody>${list.map((p,i)=>`<tr><td>${['🥇','🥈','🥉'][i]||i+1}</td><td>${esc(p.name)}</td><td>${esc(p.code)}</td><td><b>${score(p)}</b></td></tr>`).join('')}</tbody></table>`:'<div class="empty">Chưa có thí sinh tham gia.</div>'}
function join(){const name=$('name').value.trim(),code=$('code').value.trim().toUpperCase();if(!name||!code){alert('Vui lòng nhập họ tên và mã thí sinh.');return}let p=state.players.find(x=>x.code===code);if(p){p.name=name}else{p={name,code,score:0};state.players.push(p)}sessionStorage.setItem('dtt_player',code);save();location.href='contestant.html'}
function renderContestant(){
if(!$('question'))return;
const p=state.players.find(x=>x.code===me());
$('playerName').textContent=p?.name||'thí sinh';
$('myScore').textContent=p?.score||0;
const lobby=$('waitingRoom'),game=$('gameArea');
if(state.status==='waiting'){
  if(lobby)lobby.hidden=false;
  if(game)game.hidden=true;
  $('waitingName').textContent=p?.name||'—';
  $('waitingCode').textContent=p?.code||'—';
  $('waitingStatus').textContent='ĐANG CHỜ MC BẮT ĐẦU';
  return;
}
if(lobby)lobby.hidden=true;
if(game)game.hidden=false;
const q=current();
$('roundLabel').textContent=`VÒNG ${state.round} / 4`;
$('questionLabel').textContent=`CÂU ${state.index+1} / 10`;
$('progressBar').style.width=((state.round-1)*25+(state.index+1)*2.5)+'%';
$('timer').textContent=q?.seconds||20;
if(!q||state.status==='finished'){
  $('question').textContent='Cuộc thi đã hoàn thành!';
  $('topic').textContent='HOÀN THÀNH';
  $('answers').innerHTML='';
  $('feedback').textContent='Cảm ơn bạn đã tham gia Đấu trường tri thức!';
  board('leaderboard');return;
}
$('topic').textContent=q.topic.toUpperCase();
$('question').textContent=q.question;
const chosen=state.answers[me()+'_'+q.id];
$('answers').innerHTML=Object.entries(q.options).map(([k,v])=>`<button class="answer ${chosen===k?'selected':''} ${state.revealed&&q.correct===k?'correct':''} ${state.revealed&&chosen===k&&chosen!==q.correct?'wrong':''}" data-answer="${k}" ${state.revealed||state.status!=='open'?'disabled':''}><strong>${k}</strong>${esc(v)}</button>`).join('');
document.querySelectorAll('[data-answer]').forEach(b=>b.onclick=()=>answer(b.dataset.answer));
$('feedback').textContent=state.revealed?`Đáp án đúng: ${q.correct} · ${chosen===q.correct?'Chính xác!':'Bạn chưa trả lời đúng.'}`:state.status==='open'?'Hãy chọn một đáp án. Đáp án được khóa khi MC công bố.':'Đang chờ MC mở câu hỏi tiếp theo.';
board('leaderboard');
}
function answer(k){const q=current(),code=me();if(!q||state.status!=='open'||state.revealed||!code)return;state.answers[code+'_'+q.id]=k;save();renderContestant()}
function renderMC(){if(!$('mcStatus'))return;const q=current();$('mcStatus').textContent=state.status==='waiting'?'Chưa bắt đầu':state.status==='open'?'Đang nhận đáp án':state.revealed?'Đã công bố đáp án':'Đang tạm dừng';$('mcRound').textContent='VÒNG '+state.round;$('mcQuestion').textContent=`CÂU ${(state.round-1)*10+state.index+1} / 40`;$('mcProgress').style.width=(((state.round-1)*10+state.index+1)/40*100)+'%';$('mcQText').textContent=q?(state.status==='waiting'?'Sẵn sàng mở: ': '')+q.question:'Đã hoàn thành 4 vòng thi!';$('mcOptions').innerHTML=q?Object.entries(q.options).map(([k,v])=>`<div><b>${k}.</b> ${esc(v)}</div>`).join(''):'';$('mcCorrect').textContent=state.revealed&&q?`ĐÁP ÁN ĐÚNG: ${q.correct} · ${q.points} điểm`:'Đáp án sẽ hiển thị tại đây sau khi công bố.';$('playerCount').textContent=state.players.length+' thí sinh';board('mcLeaderboard')}
function start(){if(!current())return;state.status='open';state.revealed=false;save();renderMC();renderContestant()}
function reveal(){const q=current();if(!q||state.status!=='open')return;state.revealed=true;state.status='revealed';state.players.forEach(p=>{const a=state.answers[p.code+'_'+q.id];if(a===q.correct&&!p.scored?.includes(q.id)){p.score=(p.score||0)+q.points;p.scored=[...(p.scored||[]),q.id]}});save();renderMC();renderContestant()}
function next(){if(state.round===4&&state.index===9){state.status='finished';save();renderMC();renderContestant();return}if(state.index===9){state.round++;state.index=0}else state.index++;state.status='waiting';state.revealed=false;save();renderMC();renderContestant()}
function reset(){if(!confirm('Đặt lại toàn bộ trạng thái cuộc thi và điểm số?'))return;state={players:state.players.map(p=>({...p,score:0,scored:[]})),round:1,index:0,status:'waiting',revealed:false,answers:{}};save();renderMC();renderContestant()}
function renderAdmin(){if(!$('adminPlayers'))return;$('qCount').textContent=questions.length;$('aCount').textContent=state.players.length;board('adminPlayers');$('questionSummary').innerHTML=[1,2,3,4].map(n=>`<article><span>VÒNG 0${n}</span><h3>${questions.filter(q=>q.round===n).length} câu hỏi</h3><p>${questions.filter(q=>q.round===n).slice(0,2).map(q=>esc(q.topic)).join(' · ')}</p></article>`).join('')}
function csv(){const rows=[['Hang','Ho ten','Ma thi sinh','Diem'],...sorted().map((p,i)=>[i+1,p.name,p.code,p.score||0])];const content='\\ufeff'+rows.map(r=>r.map(x=>'"'+String(x).replace(/"/g,'""')+'"').join(',')).join('\\n');download('bang-diem-tay-ninh.csv',content,'text/csv;charset=utf-8')}
function download(name,data,type){const a=document.createElement('a'),url=URL.createObjectURL(new Blob([data],{type}));a.href=url;a.download=name;a.click();URL.revokeObjectURL(url)}
function adminActions(){$('export')?.addEventListener('click',csv);$('downloadQuestions')?.addEventListener('click',()=>download('questions.json',JSON.stringify(questions,null,2),'application/json'));$('clearPlayers')?.addEventListener('click',()=>{if(confirm('Xóa toàn bộ thí sinh?')){state.players=[];state.answers={};save();renderAdmin()}});$('resetAll')?.addEventListener('click',reset)}
document.addEventListener('DOMContentLoaded',async()=>{await init();$('join')?.addEventListener('click',join);$('start')?.addEventListener('click',start);$('reveal')?.addEventListener('click',reveal);$('next')?.addEventListener('click',next);$('reset')?.addEventListener('click',reset);adminActions()});
